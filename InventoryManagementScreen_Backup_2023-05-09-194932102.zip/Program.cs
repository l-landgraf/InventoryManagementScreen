﻿using Sandbox.Game.EntityComponents;
using Sandbox.ModAPI.Ingame;
using Sandbox.ModAPI.Interfaces;
using SpaceEngineers.Game.ModAPI.Ingame;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.Immutable;
using System.Linq;
using System.Text;
using VRage;
using VRage.Collections;
using VRage.Game;
using VRage.Game.Components;
using VRage.Game.GUI.TextPanel;
using VRage.Game.ModAPI.Ingame;
using VRage.Game.ModAPI.Ingame.Utilities;
using VRage.Game.ObjectBuilders.Definitions;
using VRageMath;

namespace IngameScript
{
    partial class Program : MyGridProgram
    {

        /*
          Inventory Management Screen

          Commands:
          
          increases requested amount
          <screenName> inc
          
          decreases requested amount
          <screenName> dec
          
          moves the cursor up
          <screenName> up
          
          moves the cursor down
          <screenName> down
          
          sets all requested amoutn to 0
          <screenName> reset
          
          changes to the nex stepsize
          <screenName> change
          
          
          Custom Data Default Settings:
          name       NO DEFAULT
          tag        NO DEFAULT
          filter=""
          linesAbove=2
          linesBelow=2
          stepSizes=1,10,50,100,500
          defaultStepSize=2
          screenWidth=800
         */

        string nameTag;
        string customDataTag;
        string shipTag;

        Dictionary<string, ManagedLCD> lcds = new Dictionary<string, ManagedLCD>();
        List<string> errors = new List<string>();


        MyIni ini;

        public Program()
        {
            ini = new MyIni();
            LoadCustomData();
            LoadBlocks();
            LoadCustomData();
            Runtime.UpdateFrequency = UpdateFrequency.Update100;
        }

        void LoadCustomData()
        {
            ini.TryParse(Me.CustomData);
            nameTag = ini.Get("IMS", "nameTag").ToString("[IMS]");
            customDataTag = ini.Get("IMS", "customDataTag").ToString("IMS");
            shipTag = ini.Get("IMS", "shipTag").ToString("");
        }

        public void Save()
        {
        }

        public void Main(string argument, UpdateType updateSource)
        {
            Echo("shipTag=" + shipTag);
            Echo("Managed LCDs: " + lcds.Count);
            foreach (var lcd in lcds)
            {
                Echo(lcd.Key);
            }

            if (errors.Count > 0)
            {
                Echo("Errors: ");
            }
            foreach (string str in errors)
            {
                Echo(str);
            }

            if (updateSource.HasFlag(UpdateType.Update100))
            {
                foreach (var lcd in lcds)
                {
                    lcd.Value.Recount();
                }
                //Reload();
            }

            if (!updateSource.HasFlag(UpdateType.Update100))
            {
                Commands(argument);
            }
        }

        void Commands(string argument)
        {
            string[] split = argument.Split(' ');
            if (split.Length != 2)
            {
                Log("Unknown command\n\"" + argument + "\"");
                return;
            }

            string lcdName = split[0];
            if (!lcds.ContainsKey(lcdName))
            {
                Log("Unknown lcd " + lcdName + "in \n\"" + argument + "\"");
                return;
            }
            ManagedLCD lcd = lcds[lcdName];

            if (split[1].Equals("inc", StringComparison.OrdinalIgnoreCase))
            {
                lcd.IncreaseAmount();
            }
            else if (split[1].Equals("dec", StringComparison.OrdinalIgnoreCase))
            {
                lcd.DecraseAmount();
            }
            else if (split[1].Equals("up", StringComparison.OrdinalIgnoreCase))
            {
                lcd.DecreaseSelection();
            }
            else if (split[1].Equals("down", StringComparison.OrdinalIgnoreCase))
            {
                lcd.IncreaseSelection();
            }
            else if (split[1].Equals("reset", StringComparison.OrdinalIgnoreCase))
            {
                lcd.Rest();
            }
            else if (split[1].Equals("change", StringComparison.OrdinalIgnoreCase))
            {
                lcd.ChangeStepSize();
            }
            else
            {
                Log("Unknown command\n\"" + argument + "\"");
            }
        }

        void LoadBlocks()
        {
            List<IMyTerminalBlock> terminals = new List<IMyTerminalBlock>();
            GridTerminalSystem.GetBlocksOfType<IMyTerminalBlock>(terminals, b => b.CustomName.Contains(nameTag) && b.CustomName.Contains(shipTag) && b is IMyTextSurfaceProvider);
            foreach (var term in terminals)
            {
                IMyTextSurfaceProvider provider = (IMyTextSurfaceProvider)term;
                bool foundSection = false;
                for (int i = 0; i < provider.SurfaceCount; i++)
                {
                    string section = customDataTag + " " + i;
                    ini.TryParse(term.CustomData, section);
                    if (ini.ContainsSection(section))
                    {
                        InitLCD(provider.GetSurface(i), ini, section, term.CustomName);
                        foundSection = true;
                    }
                }
                if (!foundSection)
                {
                    Log(term.CustomName);
                }
            }

            terminals.Clear();
            GridTerminalSystem.GetBlocksOfType<IMyTerminalBlock>(terminals, b => b.CustomName.Contains(nameTag) && b is IMyTextSurface);
            foreach (var term in terminals)
            {
                IMyTextSurface surface = (IMyTextSurface)term;
                ini.TryParse(term.CustomData);
                if (ini.ContainsSection(customDataTag))
                {
                    InitLCD(surface, ini, customDataTag, term.CustomName);
                }
            }
        }

        private void InitLCD(IMyTextSurface surface, MyIni ini, string section, string customName)
        {
            try
            {
                new ManagedLCD(this, surface, ini, section);
            }
            catch (Exception e)
            {
                Log(customName + " " + e.Message + " " + e.StackTrace);
            }
        }

        private void Log(string message)
        {
            errors.Insert(0, message);
        }

        bool RegisterLCD(string name, ManagedLCD lcd, string oldName)
        {
            if (oldName != null)
            {
                lcds.Remove(oldName);
            }
            try
            {
                lcds.Add(name, lcd);
            }
            catch (Exception e)
            {
                return false;
            }
            return true;
        }

        class ManagedLCD
        {
            private Program program;
            private IMyTextSurface surface;
            private List<IMyTerminalBlock> cargoContainers;

            private Dictionary<string, ItemInfo> itemList;
            private string name;
            private string tag;
            private string filter;
            private int currentSelection = 0;
            private int[] stepSizes;
            private int currentStepSize;
            private float spaceWidth;
            private int screenWidth;
            private int linesBelow;
            private int linesAbove;

            public ManagedLCD(Program program, IMyTextSurface surface, MyIni ini, string section)
            {
                this.program = program;
                this.surface = surface;

                Reload(ini, section);
            }
            public void Reload(MyIni ini, string section)
            {
                LoadConfig(ini, section);
                LoadCargoContainers();
                ReadItemData();
                spaceWidth = surface.MeasureStringInPixels(new StringBuilder(" "), surface.Font, surface.FontSize).X;
                Print();
            }


            void LoadConfig(MyIni ini, string section)
            {

                if (!ini.ContainsSection(section))
                {
                    surface.WriteText("Missing Section " + name + "[" + section + "]" + " in Custom Data.");
                    throw new Exception();
                }

                string oldName = name;
                name = LoadError(ini, section, "name").ToString();
                if (!program.RegisterLCD(name, this, oldName))
                {
                    surface.WriteText("name " + name + " already exists\nchoose a diffrent one.");
                    throw new Exception();
                }

                tag = LoadError(ini, section, "tag").ToString();

                filter = ini.Get(section, "filter").ToString("");
                linesAbove = ini.Get(section, "linesAbove").ToInt32(2);
                linesBelow = ini.Get(section, "linesBelow").ToInt32(2);
                stepSizes = Array.ConvertAll(ini.Get(section, "stepSizes").ToString("1,10,100").Split(','), int.Parse);
                currentStepSize = ini.Get(section, "defaultStepSize").ToInt32(2);
                currentStepSize = MathHelper.Clamp(currentStepSize, 0, stepSizes.Length - 1);
                screenWidth = ini.Get(section, "screenWidth").ToInt32(800);
            }

            MyIniValue LoadError(MyIni ini, string section, string name)
            {
                if (!ini.ContainsKey(section, name))
                {
                    surface.WriteText("Missing " + name + " in Custom Data.");
                    throw new Exception();
                }
                MyIniValue value = ini.Get(section, name);
                return value;
            }

            void LoadCargoContainers()
            {
                cargoContainers = new List<IMyTerminalBlock>();
                program.GridTerminalSystem.GetBlocksOfType<IMyTerminalBlock>(cargoContainers, b => b.CustomName.Contains(tag) && b is IMyInventoryOwner);
            }

            public void Recount()
            {
                string s = "";
                foreach (var entry in itemList)
                {
                    entry.Value.actualAmount = 0;
                }
                foreach (var curretContainer in cargoContainers)
                {
                    for (int i = 0; i < curretContainer.InventoryCount; i++)
                    {
                        List<MyInventoryItem> items = new List<MyInventoryItem>();
                        curretContainer.GetInventory(i).GetItems(items);
                        foreach (var item in items)
                        {
                            string itemName = item.Type.TypeId.Split('_')[1] + "/" + item.Type.SubtypeId;
                            s += itemName + "\n";
                            if (itemList.ContainsKey(itemName))
                            {
                                itemList[itemName].actualAmount += item.Amount.ToIntSafe();
                            }
                            else
                            {
                                itemList.Add(itemName, new ItemInfo(0, item.Amount.ToIntSafe()));
                            }
                        }
                    }
                }
                Print();
            }

            void ReadItemData()
            {
                itemList = new Dictionary<string, ItemInfo>();
                foreach (var container in cargoContainers)
                {
                    foreach (var line in container.CustomData.Split("\r\n".ToCharArray(), StringSplitOptions.RemoveEmptyEntries))
                    {
                        string[] split = line.Split('=');
                        if (split.Length == 2)
                        {
                            string itemName = split[0];
                            if (!itemName.StartsWith(filter))
                            {
                                continue;
                            }
                            int itemAmount = int.Parse(split[1]);
                            if (itemList.ContainsKey(itemName))
                            {
                                itemList[itemName].requestedAmount += itemAmount;
                            }
                            else
                            {
                                itemList.Add(itemName, new ItemInfo(0, itemAmount));
                            }
                        }
                    }
                }
                currentSelection = Loop(currentSelection, itemList.Count);
            }

            public void Rest()
            {
                foreach (var entry in itemList)
                {
                    entry.Value.requestedAmount = 0;
                }
                WriteAll();
                Print();
            }

            public void ChangeStepSize()
            {
                currentStepSize = Loop(currentStepSize + 1, stepSizes.Length);
                Print();
            }

            public void IncreaseAmount()
            {
                ItemInfo info = itemList.ElementAt(currentSelection).Value;
                info.requestedAmount += stepSizes[currentStepSize];
                WriteLine(itemList.ElementAt(currentSelection).Key);
                Print();
            }

            public void DecraseAmount()
            {
                ItemInfo info = itemList.ElementAt(currentSelection).Value;
                info.requestedAmount -= stepSizes[currentStepSize];
                if (info.requestedAmount < 0)
                {
                    info.requestedAmount = 0;
                }
                WriteLine(itemList.ElementAt(currentSelection).Key);
                Print();
            }

            public void IncreaseSelection()
            {
                currentSelection = Loop(currentSelection + 1, itemList.Count);
                Print();
            }

            public void DecreaseSelection()
            {
                currentSelection = Loop(currentSelection - 1, itemList.Count);
                Print();
            }

            void AddAmount()
            {
            }

            void WriteLine(string item)
            {
                for (int containerNr = 0; containerNr < cargoContainers.Count; containerNr++)
                {
                    IMyTerminalBlock container = cargoContainers[containerNr];
                    string[] lines = container.CustomData.Split("\r\n".ToCharArray(), StringSplitOptions.RemoveEmptyEntries);
                    for (int lineNr = 0; lineNr < lines.Length; lineNr++)
                    {
                        string[] split = lines[lineNr].Split('=');
                        if (split.Length != 2)
                        {
                            continue;
                        }
                        string currentItemName = split[0];
                        if (currentItemName != item)
                        {
                            continue;
                        }
                        lines[lineNr] = item + "=" + SplitItems((int)itemList[item].requestedAmount, containerNr);
                    }
                    string newData = string.Join("\n", lines);
                    container.CustomData = newData;
                }
            }

            int SplitItems(int totalAmount, int containerNr)
            {
                int value = totalAmount / cargoContainers.Count;
                if (totalAmount % cargoContainers.Count < containerNr)
                {
                    value = value + 1;
                }
                return value;
            }

            void WriteAll()
            {
                foreach (var container in cargoContainers)
                {
                    string[] lines = container.CustomData.Split("\r\n".ToCharArray(), StringSplitOptions.RemoveEmptyEntries);
                    for (int i = 0; i < lines.Length; i++)
                    {
                        string[] split = lines[i].Split('=');
                        if (split.Length != 2)
                        {
                            continue;
                        }
                        string itm = split[0];
                        if (!itemList.ContainsKey(itm))
                        {
                            continue;
                        }
                        lines[i] = itm + itemList[itm];
                    }
                    string newData = string.Join("\n", lines);
                    container.CustomData = newData;
                }

            }

            public void Print()
            {



                string text = "";
                for (int i = 0; i < stepSizes.Length; i++)
                {
                    if (i == currentStepSize)
                    {
                        text += ">>" + stepSizes[i] + "<< ";
                    }
                    else
                    {
                        text += stepSizes[i] + " ";
                    }

                }
                //text += " Containers: " + cargoContainers.Count + "\n";

                if (itemList.Count > 0)
                {
                    for (int i = currentSelection - linesBelow; i < currentSelection + linesAbove + 1; i++)
                    {
                        int index = Loop(i, itemList.Count);
                        var entry = itemList.ElementAt(index);
                        string selectionInecator;
                        string line;
                        if (i == currentSelection)
                        {
                            line = ">> ";
                            selectionInecator = " <<";
                        }
                        else
                        {
                            line = "    ";
                            selectionInecator = "    ";
                        }

                        line += (index + "").PadLeft(2);
                        string itemName = entry.Key;
                        itemName = itemName.Substring(filter.Length, itemName.Length - filter.Length);
                        line += " " + itemName;
                        line = PadRight(line, screenWidth - (int)Math.Round(MeasuerWidth(entry.Value.actualAmount.ToString())));
                        line += entry.Value.actualAmount + "/" + entry.Value.requestedAmount;
                        line += " " + selectionInecator;
                        text += line + "\n";
                    }
                }
                foreach (var container in cargoContainers)
                {
                    for (int i = 0; i < container.InventoryCount; i++)
                    {

                        text += Math.Ceiling(((float)container.GetInventory(i).CurrentVolume.RawValue / (float)container.GetInventory(i).MaxVolume.RawValue) * 100) + "% ";
                    }
                }
                surface.WriteText(text);
            }

            int Loop(int value, int max)
            {
                if (max == 0)
                {
                    return 0;
                }
                return (value + max) % max;
            }

            float MeasuerWidth(String str)
            {
                return surface.MeasureStringInPixels(new StringBuilder(str), surface.Font, surface.FontSize).X;
            }

            string PadRight(string str, int targetWidth)
            {
                float currentLength = MeasuerWidth(str);
                float targetPixelWidth = targetWidth;
                float pixelsToPad = (targetPixelWidth - currentLength);
                float spacesToPad = pixelsToPad / spaceWidth;
                return str.PadRight(str.Length + (int)Math.Round(MathHelper.Clamp(spacesToPad, 0, float.PositiveInfinity)));
            }

            class ItemInfo
            {
                public float actualAmount;
                public float requestedAmount;

                public ItemInfo(int actualAmount, int requestedAmount)
                {
                    this.actualAmount = actualAmount;
                    this.requestedAmount = requestedAmount;
                }
            }
            class ContainerInfo
            {
                public IMyTerminalBlock block;
                public float freeSpace;

                public ContainerInfo(IMyTerminalBlock block, float freeSpace)
                {
                    this.block = block;
                    this.freeSpace = freeSpace;
                }
            }
        }
    }
}